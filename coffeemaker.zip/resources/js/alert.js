window.onload = function () {

/*     Livewire.on('subir-scroll', etc5 => {

        $('html, body').animate({

            scrollTop: 0

        }, 1000);

    });

    Livewire.on('alert-guardad', x => {
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Registro guardado exitosamente',
            showConfirmButton: false,
            timer: 1500
        })


    });
    Livewire.on('alert-editado', x => {
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Your work has been saved',
            showConfirmButton: false,
            timer: 1500
        })


    });

 */

};
