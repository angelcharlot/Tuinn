@extends('layouts/Coffeemaker')
@section('css')
@endsection
@section('body')
        		@livewire('local.local')
@endsection
@push('js')

@endpush
