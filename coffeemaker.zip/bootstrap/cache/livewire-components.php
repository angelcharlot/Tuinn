<?php return array (
  'categorias.categorias' => 'App\\Http\\Livewire\\Categorias\\Categorias',
  'local.local' => 'App\\Http\\Livewire\\Local\\Local',
  'menu.menu' => 'App\\Http\\Livewire\\Menu\\Menu',
  'personal' => 'App\\Http\\Livewire\\Personal',
  'productos.productos' => 'App\\Http\\Livewire\\Productos\\Productos',
);