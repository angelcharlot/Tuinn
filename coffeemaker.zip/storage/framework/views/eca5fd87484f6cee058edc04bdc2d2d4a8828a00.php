<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
        		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('personal')->html();
} elseif ($_instance->childHasBeenRendered('VTSdxxe')) {
    $componentId = $_instance->getRenderedChildComponentId('VTSdxxe');
    $componentTag = $_instance->getRenderedChildComponentTagName('VTSdxxe');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VTSdxxe');
} else {
    $response = \Livewire\Livewire::mount('personal');
    $html = $response->html();
    $_instance->logRenderedChild('VTSdxxe', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('js/personal.js')); ?>"></script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts/Coffeemaker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coffeemaker\resources\views/negocio/index.blade.php ENDPATH**/ ?>