<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/boton_file.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('productos.productos')->html();
} elseif ($_instance->childHasBeenRendered('K6GcTF2')) {
    $componentId = $_instance->getRenderedChildComponentId('K6GcTF2');
    $componentTag = $_instance->getRenderedChildComponentTagName('K6GcTF2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('K6GcTF2');
} else {
    $response = \Livewire\Livewire::mount('productos.productos');
    $html = $response->html();
    $_instance->logRenderedChild('K6GcTF2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('js/producto.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts/Coffeemaker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coffeemaker\resources\views/productos/index.blade.php ENDPATH**/ ?>