<div class="hoja_base">

    
    <?php if($updateMode): ?>
        <?php echo $__env->make('livewire.categorias.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('livewire.categorias.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <div class=" shadow-sm overflow-hidden my-8 ">
        <div class="w-full my-4">

            <div class="rounded-t-lg overflow-hidden border  border-gray-400 p-4">

                <?php if($categoria_seleccionada): ?>

                    <ul class="flex">

                        <?php $__currentLoopData = $categoria_seleccionada; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $migas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mr-6">
                                <?php if($index != count($categoria_seleccionada) - 1): ?>
                                   <a class="text-grey-500 hover:text-blue-800" href="#"> <?php echo e($migas); ?> <i
                                        class="bi bi-chevron-right"></i></a>
                                <?php else: ?>
                                <a class="text-blue-800 hover:text-blue-800" href="#"> <?php echo e($migas); ?> <i
                                    class="bi bi-chevron-right"></i></a>

                                <?php endif; ?>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                <?php endif; ?>
            </div>


        </div>

        <div class="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-1 text-gray-600">

            <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div
                    class="border-2 grid border-gray-200 h-32 w-full rounded-sm shadow-md bg-white hover:bg-gray-100  divide-y divide-solid ">
                    <div class=" text-center text-sm">

                        <div   class=" font-semibold"><?php echo e($categoria->name); ?></div>

                    </div>
                    <div wire:click="buscar(<?php echo e($categoria->id); ?>,0)" class="p-3 text-xs ">
                        <?php echo e($categoria->descrip); ?>

                    </div>
                    <div class="grid grid-cols-2 p-1 gap-2 items-baseline "  >
                        <div wire:click="delete(<?php echo e($categoria->id); ?>)" class="border p-0 text-center rounded-md text-red-500 bg-red-200 border-red-300 hover:bg-red-500 hover:text-white  "><i class="bi bi-x-circle"></i></div>
                        <div wire:click="edit(<?php echo e($categoria->id); ?>)" class="  border p-0 text-center rounded-md text-indigo-500 bg-indigo-200 border-indigo-300  hover:bg-indigo-500 hover:text-white"><i class="bi bi-pencil"></i></div>
                    </div>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div>no hay registros</div>
            <?php endif; ?>
        </div>
        <div class="mt-5">
            <button wire:click="buscar(<?php echo e($id_atras); ?>,1)"
                class="py-2 px-4 bg-blue-500 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75">volver</button>
        </div>

    </div>
    <div wire:loading  wire:target="buscar,update,store"  class="fixed z-40 w-full h-full top-0 left-0 bg-gray-500 bg-opacity-25">
        <div class="w-ful h-full ">
            <div class="flex justify-center h-full">

                <div class="w-24 h-24 my-auto animate-spin ">
                    <img class="w-full h-full" src="<?php echo e(asset('images/load2.png')); ?>" alt="">
                </div>

            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\laragon\www\coffeemaker\resources\views/livewire/categorias/categorias.blade.php ENDPATH**/ ?>