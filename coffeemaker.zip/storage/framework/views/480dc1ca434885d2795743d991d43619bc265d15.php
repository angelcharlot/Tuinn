<div class="hoja_base">
    
    <?php if($updateMode): ?>
        <?php echo $__env->make('livewire.negocio.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('livewire.negocio.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <div class="shadow-sm overflow-hidden my-8">
        <h1 class="titulo_form ">Personal</h1>
        <table class="tabla md:text-base">
            <thead class="bg-gray-100">

                <tr class=" ">
                    <th class=" truncate">#</th>
                    <th class=" truncate">Name</th>
                    <th class=" hidden md:table-cell truncate">
                        Email</th>
                    <th class=" hidden md:table-cell truncate">
                        rol</th>
                    <th class=" hidden md:table-cell truncate" width="150px">
                        Acciones</th>
                </tr>

            </thead>


            <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tbody class="bg-white border-b-2 ">
                    <tr>
                        <td class=" "><?php echo e($usuario->id); ?></td>
                        <td class=" "><?php echo e($usuario->name); ?></td>
                        <td class=" hidden md:table-cell  ">
                            <?php echo e($usuario->email); ?></td>

                        <td class="hidden md:table-cell ">
                            <?php if(isset($usuario->getRoleNames()[0])): ?>
                                <?php echo e($usuario->getRoleNames()[0]); ?>

                            <?php endif; ?>
                        </td>

                        <td class=" hidden md:table-cell">

                            <button wire:click="edit(<?php echo e($usuario->id); ?>)"
                                class="ml-2 px-2 py-1  bg-blue-200 text-blue-500 hover:bg-blue-500 hover:text-white rounded"><i class="bi bi-pencil-fill"></i></button>
                            <button wire:click="$emit('delete',<?php echo e($usuario->id); ?>)"
                                class="ml-2 px-2 py-1  borrarr bg-red-200 text-red-500 hover:bg-red-500 hover:text-white rounded"><i class="bi bi-trash"></i></button>


                        </td>
                    </tr>
                    <tr class="visible md:hidden ">
                        <td class=" border-slate-100  p-2 md:p-4 text-gray-400" colspan="2">Email:
                            <?php echo e($usuario->email); ?></td>
                    </tr>
                    <tr class="visible md:hidden ">
                        <td class=" border-slate-100  p-2 md:p-4 text-gray-400" colspan="2">Rol:
                            <?php if(isset($usuario->getRoleNames()[0])): ?>
                                <?php echo e($usuario->getRoleNames()[0]); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr class="visible md:hidden ">
                        <td class=" border-slate-100  p-2 md:p-4 text-gray-400" colspan="2">
                            <button wire:click="edit(<?php echo e($usuario->id); ?>)"
                                class="px-2  bg-blue-200 text-blue-500 hover:bg-blue-500 hover:text-white rounded">Editar</button>
                            <button wire:click="$emit('delete',<?php echo e($usuario->id); ?>)"
                                class="px-2 borrarr  bg-red-200 text-red-500 hover:bg-red-500 hover:text-white rounded">Borrar</button>
                        </td>
                    </tr>

                </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-5 m-2 text-center text-4xl font-serif tracking-wide">
                    <h1> no hay registros</h1>
                </div>
            <?php endif; ?>



        </table>





    </div>

</div>
<?php /**PATH C:\laragon\www\coffeemaker\resources\views/livewire/negocio/personal.blade.php ENDPATH**/ ?>