<div class=" bg-whitem mb-10 h-min-screen my-10 container mx-auto rounded-md shadow-sm ">

    <div class="w-full my-3">
        <div class="w-full">
            <img src="<?php echo e(asset($negocio->img)); ?>" alt="">
        </div>

        <div class="text-center  mt-3 text-lg font-bold"><?php echo e($negocio->name); ?></div>
        <div class="text-center text-md"><?php echo e($negocio->direccion); ?></div>
        <div class="text-center mb-3 text-xs"><?php echo e($negocio->nif); ?></div>
    </div>

    
    <div class="div-form-container grid grid-cols-4 gap-1 mb-5">
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($categoria->productos) > 0): ?>
                <div
                    class=" col-span-1 cursor-pointer  border-b-4  border-gray-100 bg-white h-8 font-bold text-xs text-center py-1 rounded-sm  hover:border-indigo-700 hover:shadow-2xl  ">
                    <div wire:click="navegacion(<?php echo e($categoria->id); ?>,0)"> <?php echo e($categoria->name); ?> <div
                            class=" inline-block bg-blue-500 rounded-2xl w-6 my-1 text-white boder border-blue-800">
                            <?php echo e(count($categoria->productos)); ?></div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class=" grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 text-xs mx-auto">

        <?php $__currentLoopData = $categoria_padre->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div
                class=" grid-cols-2 grid border border-gray-200 m-1 rounded-md shadow-xs p-1 hover:border-indigo-300 hover:shadow-2xl ">
                <div><img class="w-full rounded-md" src="<?php echo e(asset($producto->img)); ?>" alt="Sunset in the mountains">
                </div>
                <div>
                    <table class="w-full ">
                        <tbody>
                            <tr>
                                <td class=" text-center font-extrabold  ">
                                    <?php echo e($producto->name); ?>

                                </td>
                            </tr>

                            <tr>
                                <td class="text-center text-green-900 text-2xl font-medium ">
                                    &euro; <?php echo e($producto->precio_venta); ?>

                                </td>
                            </tr>
                        </tbody>
                    </table>

                </div>
                <div class="col-span-2 text-ellipsis overflow-hidden ... h-10  ">
                    <?php echo e($producto->descrip); ?>

                </div>
                <div class="col-span-2">
                    <?php $__currentLoopData = $producto->categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span style="font-size: 8px;line-height: 11px;letter-spacing: 0.027em;font-weight: 875;"
                            class="inline-block bg-gray-200 rounded-full px-1 py-1  font-semibold text-gray-700 mr-2 mb-2">#<?php echo e($categoria->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="mt-5 w-full flex-row text-center mb-10">
        <button wire:click="navegacion('<?php echo e($categoria_padre->id); ?>',1)"
            class="py-2 px-4  bg-blue-500 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75">volver</button>
    </div>


</div>
<?php /**PATH C:\laragon\www\coffeemaker\resources\views/livewire/menu/menu.blade.php ENDPATH**/ ?>