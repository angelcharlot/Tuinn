<div class="w-full">
    <h1 class="titulo_form">
        Registrar categoria</h1>
        <div class="div-form-container grid grid-cols-1 sm:grid-cols-2 ">

         
         <div class="w-auto px-3 hidden ">
            <label class="text-xs text-gray-500 mx-1 " for="name">pertenese a:</label>
            <input disabled
                class=""
                id="name" wire:model="id_padre_categoria" type="text" placeholder="">
            <?php $__errorArgs = ['id_padre_categoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-500 text-xs italic"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="w-auto px-3">
            <label class="text-xs text-gray-500 mx-1 " for="name">Nombre</label>
            <input
                class=""
                id="name" wire:model="name" type="text" placeholder="Nombre completo...">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-500 text-xs italic"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
          
          <div class="w-auto px-3">
            <label class="text-xs text-gray-500 mx-1 " for="name">Drescripcion</label>
            <input
                class=""
                id="name" wire:model="descrip" type="text" placeholder="">
            <?php $__errorArgs = ['descrip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-500 text-xs italic"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
        </div>
        <div class="w-auto pl-3 text-center align-middle col-span-1 md:col-span-3 sm:grid-cols-2">
            <div class="pt-5">
                <button wire:click="store()"
                    class="px-3 py-2 bg-indigo-200 text-indigo-500 hover:bg-indigo-500 hover:text-indigo-100 rounded">Agregar</button>
            </div>
        </div>

        </div>



</div>
<?php /**PATH C:\laragon\www\coffeemaker\resources\views/livewire/categorias/create.blade.php ENDPATH**/ ?>