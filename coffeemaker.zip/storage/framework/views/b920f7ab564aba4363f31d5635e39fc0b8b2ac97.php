
<?php for($i = 0; $i < count($categorias->cat_hijos_todos); $i++): ?>
    <?php
        $categorias->cat_hijos_todos[$i]->profundidad = $categorias->profundidad + 1;
        $categorias->cat_hijos_todos[$i]->ids .= $categorias->ids."-".$categorias->cat_hijos_todos[$i]->id;
    ?>
<?php endfor; ?>
<?php if(count($categorias->cat_hijos_todos) > 0): ?>

<span role="menuitem" tabindex="-1"
    class=" pl-<?php echo e($categorias->profundidad*4); ?> bg-gray-100 h-8 pt-1 flex justify-between w-full px-4  text-sm leading-5 text-left text-black font-extrabold  cursor-not-allowed "
    >
    <?php echo e($categorias->name); ?>--<?php echo e($categorias->ids); ?>

</span>
<?php echo $__env->renderEach('livewire.productos.partial',$categorias->cat_hijos_todos, 'categorias'); ?>
<?php else: ?>
<a wire:click="changeEvent(<?php echo e($categorias->id); ?>,'<?php echo e($categorias->name); ?>','<?php echo e($categorias->ids); ?>')" tabindex="0" aria-haspopup="false" aria-expanded="false" aria-controls="headlessui-menu-items-117"
class=" pl-<?php echo e($categorias->profundidad*4); ?> hover:bg-blue-500 text-gray-700 flex justify-between w-full px-4 py-2 text-sm leading-5 text-left" role="menuitem">
<?php echo e($categorias->name); ?><?php echo e($categorias->ids); ?>

</a>


<?php endif; ?>

<?php /**PATH C:\laragon\www\coffeemaker\resources\views/livewire/productos/partial.blade.php ENDPATH**/ ?>