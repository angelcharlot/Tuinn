<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('menu.menu',['id_negocio' => $id_negocio])->html();
} elseif ($_instance->childHasBeenRendered('MGBJV4q')) {
    $componentId = $_instance->getRenderedChildComponentId('MGBJV4q');
    $componentTag = $_instance->getRenderedChildComponentTagName('MGBJV4q');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MGBJV4q');
} else {
    $response = \Livewire\Livewire::mount('menu.menu',['id_negocio' => $id_negocio]);
    $html = $response->html();
    $_instance->logRenderedChild('MGBJV4q', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('js/personal.js')); ?>"></script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts/menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coffeemaker\resources\views/menu/index.blade.php ENDPATH**/ ?>