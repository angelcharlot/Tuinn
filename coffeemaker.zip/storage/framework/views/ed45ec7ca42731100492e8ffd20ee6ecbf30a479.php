<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('menu.menu',['id_negocio' => $id_negocio])->html();
} elseif ($_instance->childHasBeenRendered('4MlsQIR')) {
    $componentId = $_instance->getRenderedChildComponentId('4MlsQIR');
    $componentTag = $_instance->getRenderedChildComponentTagName('4MlsQIR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4MlsQIR');
} else {
    $response = \Livewire\Livewire::mount('menu.menu',['id_negocio' => $id_negocio]);
    $html = $response->html();
    $_instance->logRenderedChild('4MlsQIR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('js/personal.js')); ?>"></script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts/menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coffeemaker\resources\views/menu/index.blade.php ENDPATH**/ ?>