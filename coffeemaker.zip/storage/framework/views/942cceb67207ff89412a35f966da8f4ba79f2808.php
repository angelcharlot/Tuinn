<a href="/">

    <img src="<?php echo e(asset('images/icons8-coffe-64.png')); ?>" class="w-16 h-16" alt="">
</a>

<?php /**PATH C:\laragon\www\coffeemaker\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>