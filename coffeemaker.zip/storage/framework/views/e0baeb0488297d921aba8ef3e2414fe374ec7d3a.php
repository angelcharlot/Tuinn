<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'COffeemaker')); ?></title>
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    
    <?php echo $__env->yieldContent('css'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

    <!-- Scripts -->

</head>

<body class="bg-gray-100">
    <header>
    </header>
    <div class="containner mx-auto">
        <?php echo $__env->yieldContent('body'); ?>
    </div>
    <?php echo $__env->yieldPushContent('modals'); ?>
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo $__env->yieldPushContent('js'); ?>


</body>

</html>
<?php /**PATH C:\laragon\www\coffeemaker\resources\views/layouts/menu.blade.php ENDPATH**/ ?>