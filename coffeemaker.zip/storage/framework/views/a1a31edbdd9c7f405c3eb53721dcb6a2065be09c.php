<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
        		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('categorias.categorias')->html();
} elseif ($_instance->childHasBeenRendered('5VO8e3m')) {
    $componentId = $_instance->getRenderedChildComponentId('5VO8e3m');
    $componentTag = $_instance->getRenderedChildComponentTagName('5VO8e3m');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5VO8e3m');
} else {
    $response = \Livewire\Livewire::mount('categorias.categorias');
    $html = $response->html();
    $_instance->logRenderedChild('5VO8e3m', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/Coffeemaker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coffeemaker\resources\views/productos/categorias.blade.php ENDPATH**/ ?>