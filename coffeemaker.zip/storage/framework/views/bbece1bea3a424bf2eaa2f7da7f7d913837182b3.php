<div>
    <h1 class="titulo_form">
        Actualizar producto</h1>
    
    <form wire:submit.prevent="update()">
        <div class="div-form-container grid grid-cols-1  md:grid-cols-4">

            <div class="px-3 text-left">
                <label class="text-xs text-gray-500 mx-1 " for="">nombre</label>
                <input type="text" placeholder="cañan Cruz campo" name="name" id="name" wire:model="name"
                    class="block  w-full mx-1 my-1 bg-gray-50 rounded text-sm border borde-gray-200 focus:outline-none focus:shadow-md shadow-xs h-10 px-2 focus:bg-gray-100 focus:border-gray-600">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-xs italic"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="px-3 text-left sm:col-span-1 md:col-span-2">
                <label class="text-xs text-gray-500 mx-1 " for="">Descripcion</label>
                <input type="text" wire:model="descrip"
                    placeholder="contenido alcohólico de 5,9% en volumen. De color dorado intenso y aroma afrutado, capaz de transformar los momentos cotidianos en instantes cruciales. Con un amargor moderado y aromático, coronada por una espuma de color blanco roto."
                    name="descrip" id="descrip"
                    class="block  w-full mx-1 my-1 bg-gray-50 rounded text-sm border borde-gray-200 focus:outline-none focus:shadow-md shadow-xs h-10 px-2 focus:bg-gray-100 focus:border-gray-600">
                <?php $__errorArgs = ['descrip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-xs italic"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="px-3 text-left">
                <label class="text-xs text-gray-500 mx-1 " for="">precio de compra</label>
                <input type="number" step="0.01" autocomplete="true" placeholder="1.00" name="p_compra"
                    id="p_compra" wire:model="p_compra"
                    class="block  w-full mx-1 my-1 bg-gray-50 rounded text-sm border borde-gray-200 focus:outline-none focus:shadow-md shadow-xs h-10 px-2 focus:bg-gray-100 focus:border-gray-600">
                <?php $__errorArgs = ['p_compra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-xs italic"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="px-3 text-left">
                <label class="text-xs text-gray-500 mx-1 " for="">precio de venta</label>
                <input type="number" step="0.01" autocomplete="true" placeholder="1.20" name="p_venta"
                    id="p-venta" wire:model="p_venta"
                    class="block  w-full mx-1 my-1 bg-gray-50 rounded text-sm border borde-gray-200 focus:outline-none focus:shadow-md shadow-xs h-10 px-2 focus:bg-gray-100 focus:border-gray-600">
                <?php $__errorArgs = ['p_venta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-xs italic"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="px-3 text-left hidden">
                <label class="text-xs text-gray-500 mx-1 " for="">peso(gramos(g))</label>
                <input type="number" step="0.01" autocomplete="true" placeholder="100" id="peso" name="peso"
                    wire:model="peso"
                    class="block  w-full mx-1 my-1 bg-gray-50 rounded text-sm border borde-gray-200 focus:outline-none focus:shadow-md shadow-xs h-10 px-2 focus:bg-gray-100 focus:border-gray-600">
                <?php $__errorArgs = ['peso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-xs italic"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="px-3 text-left">
                <label class="text-xs text-gray-500 mx-1 " for="">unidad de medida (ml,L,etc)</label>
                <select placeholder="200" value="Ml" id="unidad_medida" name="unidad_medida"
                    wire:model="unidad_medida"
                    class="block  w-full mx-1 my-1 bg-gray-50 rounded text-sm border borde-gray-200 focus:outline-none focus:shadow-md shadow-xs h-10 px-2 focus:bg-gray-100 focus:border-gray-600">

                    <option value="ml" selected>mililitro (ml)</option>
                    <option value="cl">centilitro (cl)</option>
                    <option value="dl">decilitro (dl)</option>

                </select>
                <?php $__errorArgs = ['unidad_medida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-xs italic"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="px-3 text-left ">
                <label class="text-xs text-gray-500 mx-1 " for="">volumen</label>
                <input type="number" step="0.01" autocomplete="true" placeholder="1" id="volumen" name="volumen"
                    wire:model="volumen"
                    class="block  w-full mx-1 my-1 bg-gray-50 rounded text-sm border borde-gray-200 focus:outline-none focus:shadow-md shadow-xs h-10 px-2 focus:bg-gray-100 focus:border-gray-600">
                <?php $__errorArgs = ['volumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-xs italic"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="px-3">

                <label class="text-xs text-gray-500 mx-1  " for="">Categoria</label>

                <div class=" relative z-30 inline-block text-left dropdown w-full my-1">
                    <span id="btn-dropdown" wire:click="$emit('btn')" class="rounded-md shadow-sm"><button
                            class="inline-flex justify-center w-full px-4 py-2 text-sm font-medium leading-5 text-gray-700 transition duration-150 ease-in-out bg-white border border-gray-300 rounded-md hover:text-gray-500 focus:outline-none focus:border-blue-300 focus:shadow-outline-blue active:bg-gray-50 active:text-gray-800"
                            type="button" aria-haspopup="true" aria-expanded="true"
                            aria-controls="headlessui-menu-items-117">
                            <span>Categoria(<?php echo e($nombre_categoria); ?>)</span>
                            <svg class="w-5 h-5 ml-2 -mr-1" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd"
                                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                                    clip-rule="evenodd"></path>
                            </svg>
                        </button></span>
                    <div
                        class=" invisible dropdown-menu  transition-all duration-300 transform origin-top-right -translate-y-2 scale-95">
                        <div class="absolute w-full right-0  mt-2 origin-top-right bg-white border border-gray-200 divide-y divide-gray-100 rounded-md shadow-lg outline-none"
                            aria-labelledby="headlessui-menu-button-1" id="headlessui-menu-items-117" role="menu">

                            <div class="py-1">

                                <?php echo $__env->renderEach('livewire.productos.partial', $allcategorias, 'categorias'); ?>


                            </div>

                        </div>
                    </div>
                </div>
                <input type="text" wire:model="categorias" class=" hidden ">
                <?php $__errorArgs = ['categorias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-xs italic"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="px-3 text-left md:col-span-2">
                <label class="text-xs text-gray-500 mx-1 " for="">imagen</label>
                <div class="subir_foto ">
                    <button
                        class="file_cam">Subir
                        Archivo</button>
                    <input class="imputable " type="file" name="photo" accept="image/png, image/gif, image/jpeg" id="photo"
                        wire:model="photo" />
                    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="px-3 md:m-2 m-1 ">
                <?php if($photo): ?>
                    <img class="h-16 mx-auto w-16 object-cover rounded-lg border border-gray-200"
                        src="<?php echo e($photo->temporaryUrl()); ?>" alt="Current profile photo" />
                <?php else: ?>
                    <img class="h-16 mx-auto w-16 object-cover rounded-lg border border-gray-200"
                        src="<?php echo e(asset('images/icons8-cubiertos-100.png')); ?>" alt="Current profile photo" />
                <?php endif; ?>

            </div>
            <div class="text-left md:col-span-4">
                <div class="w-auto pl-3 text-center align-middle">
                    <div class="pt-5">
                        <button
                            class="px-3 py-2 bg-indigo-200 text-indigo-500 hover:bg-indigo-500 hover:text-indigo-100 rounded">Actualizar
                            producto</button>
                        <a wire:click="cancelar()"
                            class="px-3 py-2 bg-red-200 text-red-500 hover:bg-red-500 hover:text-indigo-100 rounded">cancelar</a>
                    </div>
                </div>

            </div>

        </div>

    </form>
</div>
<?php /**PATH C:\laragon\www\coffeemaker\resources\views/livewire/productos/update.blade.php ENDPATH**/ ?>