window.$ = require('jquery');
require('./bootstrap');
/* require('./alert'); */
require('alpinejs');

